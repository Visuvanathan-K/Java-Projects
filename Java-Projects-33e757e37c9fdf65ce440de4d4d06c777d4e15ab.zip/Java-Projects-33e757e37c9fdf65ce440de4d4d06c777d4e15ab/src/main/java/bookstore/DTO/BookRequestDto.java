package bookstore.DTO;

import java.util.List;

public class BookRequestDto {

    private List<BookDTO> books;

    public List<BookDTO> getBooks() {
        return books;
    }

    public void setBooks(List<BookDTO> books) {
        this.books = books;
    }
}
