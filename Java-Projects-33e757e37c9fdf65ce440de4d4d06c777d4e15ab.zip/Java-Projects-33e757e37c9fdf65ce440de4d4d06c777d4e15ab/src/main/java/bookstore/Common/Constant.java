package bookstore.Common;

public interface Constant {

    interface user_type{
        String NORMAL = "NORMAL";
        String ADMIN = "ADMIN";
    }
}
