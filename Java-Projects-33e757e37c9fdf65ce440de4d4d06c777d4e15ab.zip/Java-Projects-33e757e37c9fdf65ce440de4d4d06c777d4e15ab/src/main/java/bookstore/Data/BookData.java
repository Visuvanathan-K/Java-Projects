package bookstore.Data;

import bookstore.Entity.Book;

import java.util.List;

public class BookData {

    public List<Book> books;

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
